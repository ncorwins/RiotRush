//
//  RiotRush2App.swift
//  RiotRush2
//
//  Created by school on 9/3/22.
//

import SwiftUI

@main
struct RiotRush2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
